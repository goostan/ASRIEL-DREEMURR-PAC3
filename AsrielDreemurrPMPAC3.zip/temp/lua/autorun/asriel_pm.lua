--Add Playermodel
player_manager.AddValidModel( "Asriel Dreemurr PM", "models/vicenticotd/asriel/asriel_dreemurr_pm.mdl" )
player_manager.AddValidHands( "Asriel Dreemurr PM", "models/weapons/arms/asriel_arms.mdl", 0, "0000000" )